import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      Bakery     
    </div>
  );
}

export default App;
